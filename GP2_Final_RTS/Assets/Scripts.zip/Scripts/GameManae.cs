﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class GameManae : MonoBehaviour
{
    // Start is called before the first frame update
    GameObject game;
    public GuardControl gc;
    public MoveOnClick moc;
    public SideKick sk;

    SceneManager scene;

    float resetTime;
    void Start()
    {
        game = GameObject.FindGameObjectWithTag("Player");
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ResetGame()
    {
        SceneManager.LoadScene("Finite State Machine");
    }
}
