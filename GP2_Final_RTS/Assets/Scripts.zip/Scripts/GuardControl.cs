﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GuardControl : MonoBehaviour
{
    public Transform player;
    float fovDist = 100.0f;
    float fovAngle = 90.0f;
    float chasingSpeed;
    float chasingRotSpeed;
    float chasingAcc = 1.0f;

    float patrolDist = 10.0f;
    float patrolWait = 5.0f;
    float patrolTimePassed = 0f;

    float hungerTimePassed = 0f;

    Material mat;

    enum GuardState { Patrol, Investiage, Chase}
    GuardState state;

    //where the player was last seen
    Vector3 lastPlaceSeen;
    Vector3 StartPosition = new Vector3(-3.25f, 0.5f, -6.43f);
    //investigation / knock
    float KnockRadius = 30.0f;

    // Start is called before the first frame update
    void Start()
    {
        transform.position = StartPosition;
        patrolTimePassed = patrolWait;
        lastPlaceSeen = this.transform.position;
        mat = gameObject.GetComponent<Renderer>().material;
        chasingSpeed = 2.0f;
        chasingRotSpeed = 2.0f;
        this.GetComponent<UnityEngine.AI.NavMeshAgent>().ResetPath();
    }

    // Update is called once per frame
    void Update()
    {
        //Debug.DrawRay(transform.position, transform.forward, Color.green);
        if (Input.GetKey(KeyCode.Space))
        {
            StartCoroutine(PlayKnock());
        }

        Collider[] hitColliders = Physics.OverlapSphere(transform.position, KnockRadius);

        for(int i = 0; i < hitColliders.Length; i++)
        {
            if(hitColliders[i].tag == "guard")
            {
                hitColliders[i].GetComponent<GuardControl>().InvestigatePoint(this.transform.position);
            }
        }

        HungerAggression();

        GuardState tmpState = state;

        if (CanSee(player))
        {
            state = GuardState.Chase;
        }
        else if (state == GuardState.Chase)
        {
            state = GuardState.Investiage;
        }

        switch (state)
        {
            case GuardState.Patrol:
                Patrol();
                break;
            case GuardState.Investiage:
                Investigate();
                break;
            case GuardState.Chase:
                Chase(player);
                break;
        }

        
    }

    public void PlayerDeadReset()
    {
        Start();
    }

    void Patrol()
    {
        patrolTimePassed += Time.deltaTime;
        if(patrolTimePassed > patrolWait)
        {
            patrolTimePassed = 0;
            Vector3 patrolPoint = lastPlaceSeen;
            patrolPoint += new Vector3(Random.Range(-patrolDist, patrolDist), 0f, Random.Range(-patrolDist, patrolDist));
            Debug.Log(chasingSpeed.ToString());
            this.GetComponent<UnityEngine.AI.NavMeshAgent>().SetDestination(patrolPoint);
        }
    }

    void Investigate()
    {
        if(this.transform.position == lastPlaceSeen)
        {
            state = GuardState.Patrol;
            Debug.Log("Hi");
        }
        else
        {
            this.GetComponent<UnityEngine.AI.NavMeshAgent>().SetDestination(lastPlaceSeen);
            Debug.Log($"Guard's state: {state} point {lastPlaceSeen}");
        }
    }

    void Chase(Transform player)
    {
        this.GetComponent<UnityEngine.AI.NavMeshAgent>().Stop();
        this.GetComponent<UnityEngine.AI.NavMeshAgent>().ResetPath();
        Debug.Log(chasingSpeed.ToString());
        Vector3 direction = player.position - this.transform.position;
        this.transform.rotation = Quaternion.Slerp(this.transform.rotation, Quaternion.LookRotation(direction), Time.deltaTime * this.chasingRotSpeed);

        if (direction.magnitude > this.chasingAcc)
        {
            this.gameObject.transform.Translate(0, 0, Time.deltaTime * this.chasingSpeed);
            lastPlaceSeen = player.position;
        }
    }
    bool CanSee(Transform player)
    {
        Vector3 direction = player.position - this.transform.position;
        float angle = Vector3.Angle(direction, this.transform.position);

        RaycastHit hit;
        if(Physics.Raycast(this.transform.position, direction, out hit) && 
           hit.collider.gameObject.tag == "Player" && direction.magnitude < fovDist && angle < fovAngle){
            
            return true;
        }
        return false;
    }

    void HungerAggression()
    {
        hungerTimePassed += Time.deltaTime;
        
        if(20 >= hungerTimePassed && hungerTimePassed > 10)
        {
            mat.color = new Color32(140, 56, 171, 255);
            chasingRotSpeed = 4.0f;
            chasingSpeed = 4.0f;
        }
        if (30 >= hungerTimePassed && hungerTimePassed > 20)
        {
            mat.color = new Color32(207, 46, 138, 255);
            chasingRotSpeed = 5.0f;
            chasingSpeed = 5.0f;
        }
        if (hungerTimePassed > 30)
        {
            mat.color = new Color32(255, 25, 19, 255);
            chasingRotSpeed = 6.0f;
            chasingSpeed = 6.0f;
        }
    }

    public void InvestigatePoint(Vector3 point)
    {
        lastPlaceSeen = point;
        state = GuardState.Investiage;
    }

    IEnumerator PlayKnock()
    {
        AudioSource audio = GetComponent<AudioSource>();
        audio.Play();
        yield return new WaitForSeconds(audio.clip.length);
    }
}
