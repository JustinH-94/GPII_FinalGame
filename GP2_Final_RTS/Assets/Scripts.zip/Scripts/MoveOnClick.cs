﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
public class MoveOnClick : MonoBehaviour
{
    NavMeshAgent agent;

    Vector3 StartPosition = new Vector3(-2.5f, 0.5f, 2.27f);
    // Start is called before the first frame update
    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        transform.position = StartPosition;
        this.gameObject.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        InteractionMovement();
    }
    void InteractionMovement()
    {
        if (Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 100))
            {
                this.GetComponent<NavMeshAgent>().SetDestination(hit.point);
            }
        }
    }

    public void PlayerDeadReset()
    {
         Start();
    }

}
