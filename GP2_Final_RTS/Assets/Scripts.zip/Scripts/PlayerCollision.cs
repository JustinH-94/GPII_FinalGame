﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
    
    bool isPlayerDead;
    public GameManae gm;
    // Start is called before the first frame update
    void Start()
    {
        isPlayerDead = false;
    }


    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag =="Guard")
        {
            gm.ResetGame();
        }
    }
}
