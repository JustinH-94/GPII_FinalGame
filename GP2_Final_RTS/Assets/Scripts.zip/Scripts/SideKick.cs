﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SideKick : MonoBehaviour
{
    public Transform player;
    public Transform guard;
    Vector3 StartPosition = new Vector3(-1.55f, 0.12f, 2.22f);

    float rotSpeed = 4.0f;
    float followSpeed = 4.0f;
    float followAcc = 1.0f;

    float rotProtecSpeed = 5.0f;
    float proteccSpeed = 4.0f;
    float proteccAcc = 1.0f;

    enum SKState { follow, protect }
    SKState state;
    // Start is called before the first frame update
    void Start()
    {
        state = SKState.follow;
        transform.position = StartPosition;
    }

    // Update is called once per frame
    void Update()
    {
        switch (state)
        {
            case SKState.follow:
                FollowPlayer();
                break;
            case SKState.protect:
                ProtectPlayer();
                break;
        }
    }

    void FollowPlayer()
    {
        Vector3 direction = player.position - this.transform.position;
        this.transform.rotation = Quaternion.Slerp(this.transform.rotation, Quaternion.LookRotation(direction), Time.deltaTime * this.rotSpeed);

        if (direction.magnitude > this.followAcc)
        {
            this.gameObject.transform.Translate(0, 0, Time.deltaTime * this.followSpeed);
        }
    }

    void ProtectPlayer()
    {
        Vector3 direction = guard.position - this.transform.position;
        this.transform.rotation = Quaternion.Slerp(this.transform.rotation, Quaternion.LookRotation(direction), Time.deltaTime * this.rotProtecSpeed);

        if (direction.magnitude > this.proteccAcc)
        {
            this.gameObject.transform.Translate(0, 0, Time.deltaTime * this.proteccSpeed);
        }
    }

    public void PlayerDeadReset()
    {
        Start();
    }

    public void BlockGuard(bool isGuardNearBy)
    {
        if (isGuardNearBy)
            state = SKState.protect;
        else
            state = SKState.follow;
    }
}
