﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vicinity : MonoBehaviour
{
    public SideKick sk;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Guard")
        {
            sk.BlockGuard(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "Guard")
        {
            sk.BlockGuard(false);
        }
    }
}
